// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _ASSETS_SPRITES_006_H_
#define _ASSETS_SPRITES_006_H_

#include <types.h>
#define SPRITE_006_W 50
#define SPRITE_006_H 40
extern const u8 sprite_006[50 * 40];

#endif
