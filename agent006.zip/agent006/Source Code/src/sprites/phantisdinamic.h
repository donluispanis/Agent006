// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _ASSETS_SPRITES_PHANTISDINAMIC_H_
#define _ASSETS_SPRITES_PHANTISDINAMIC_H_

#include <types.h>
#define SPRITE_PHANTISDINAMIC_0_W 4
#define SPRITE_PHANTISDINAMIC_0_H 16
extern const u8 sprite_phantisdinamic_0[4 * 16];
#define SPRITE_PHANTISDINAMIC_1_W 4
#define SPRITE_PHANTISDINAMIC_1_H 16
extern const u8 sprite_phantisdinamic_1[4 * 16];
#define SPRITE_PHANTISDINAMIC_2_W 4
#define SPRITE_PHANTISDINAMIC_2_H 16
extern const u8 sprite_phantisdinamic_2[4 * 16];
#define SPRITE_PHANTISDINAMIC_3_W 4
#define SPRITE_PHANTISDINAMIC_3_H 16
extern const u8 sprite_phantisdinamic_3[4 * 16];
#define SPRITE_PHANTISDINAMIC_4_W 4
#define SPRITE_PHANTISDINAMIC_4_H 16
extern const u8 sprite_phantisdinamic_4[4 * 16];
#define SPRITE_PHANTISDINAMIC_5_W 4
#define SPRITE_PHANTISDINAMIC_5_H 16
extern const u8 sprite_phantisdinamic_5[4 * 16];
#define SPRITE_PHANTISDINAMIC_6_W 4
#define SPRITE_PHANTISDINAMIC_6_H 16
extern const u8 sprite_phantisdinamic_6[4 * 16];

#endif
