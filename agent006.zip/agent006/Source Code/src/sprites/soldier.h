// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _ASSETS_SPRITES_SOLDIER_H_
#define _ASSETS_SPRITES_SOLDIER_H_

#include <types.h>
#define SPRITE_SOLDIER_0_W 5
#define SPRITE_SOLDIER_0_H 20
extern const u8 sprite_soldier_0[5 * 20];
#define SPRITE_SOLDIER_1_W 5
#define SPRITE_SOLDIER_1_H 20
extern const u8 sprite_soldier_1[5 * 20];

#endif
